# Проект "Комментарии"

https://glebkaf.github.io/webdev-dom-homework/

Верстка для учебного проекта студентов Skypro

## Как разрабатывать

Открой index.html в браузере
